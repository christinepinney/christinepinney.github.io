import pyspark
from pyspark.sql import (
    SparkSession,
    functions as F,
    types as T
)
import os

spark = (
    SparkSession.builder
    .appName("my_project1_app")
    .getOrCreate()
)

# read in parquet files
(
    spark.read
    .parquet("s3://bsu-c535-fall2024-commons/arjun-workspace/linktarget/")
    .createOrReplaceTempView("linktarget")
)

(
    spark.read
    .parquet("s3://bsu-c535-fall2024-commons/arjun-workspace/page/")
    .createOrReplaceTempView("page")
)

(
    spark.read
    .parquet("s3://bsu-c535-fall2024-commons/arjun-workspace/pagelinks/")
    .createOrReplaceTempView("pagelinks")
)

(
    spark.read
    .parquet("s3://bsu-c535-fall2024-commons/arjun-workspace/redirect/")
    .createOrReplaceTempView("redirect")
)

# connect pages and linktarget ids
# (page_id | page_title | linktarget_id | redirect? | namespace)
(
    spark.table("page")
    .join(
        spark.table("linktarget"),
        F.expr("lt_title = page_title and lt_namespace = page_namespace"),
        "inner"
    )
    .selectExpr("page_id", "page_title", "lt_id", "page_is_redirect as redirect", "page_namespace")
    .createOrReplaceTempView("page_with_link_ids")
)

# connect redirect source pages with corresponding destination pages 
# (rd_src_page_id | rd_dst_dst_page_id | namespace)
(
    spark.table("page_with_link_ids")
    .filter("redirect = false") # don't want redirects that link to redirects
    .join(
        spark.table("redirect"),
        F.expr("rd_title = page_title and rd_namespace = page_namespace"),
        "inner"
    )
    .selectExpr("rd_from", "page_id as rd_dst", "page_namespace as rd_namespace")
    .createOrReplaceTempView("redirect_pages")
)

# connect the destination page of a redirect to the linktarget id of the redirect source,
# this means pages that link to redirect linktarget ids in the pagelinks table will be linked
# with the page id of the redirect destination rather than the source
# (rd_dst_page_id | rd_src_linktarget_id | namespace)
(
    spark.table("page_with_link_ids")
    .filter("redirect = true") # get all redirects
    .join(
        spark.table("redirect_pages"),
        F.expr("page_id = rd_from and page_namespace = rd_namespace"),
        "inner"
    )
    .selectExpr("rd_dst as page_id", "lt_id", "rd_namespace as page_namespace")
    .createOrReplaceTempView("redirect_with_link_ids")
)

# union together non-redirects and redirects
# (page_id | linktarget_id | namespace)
# (rd_dst_page_id | rd_src_linktarget_id | namespace)
(
    spark.table("page_with_link_ids")
    .filter("redirect = false") # non-redirects
    .select("page_id", "lt_id", "page_namespace")
    .union(spark.table("redirect_with_link_ids")) # redirects
    .select("page_id", "lt_id", "page_namespace")
    .createOrReplaceTempView("all_pages_with_links")
)

# get pagelinks from source to destination and create pairs
(
    spark.table("all_pages_with_links")
    .join(
        spark.table("pagelinks"),
        F.expr("pl_target_id = lt_id and pl_from_namespace = page_namespace"),
        "inner"
    )
    .selectExpr("pl_from as page_a", "page_id as page_b")
    .filter(F.expr("page_a != page_b")) # don't want pages that link to themselves
    .withColumn("pair", F.sort_array(F.array(F.col("page_a"), F.col("page_b")))) # get pairs
    .repartition("pair") # repartition to speed aggregation up
    .groupBy("pair") 
    .agg(F.count("*").alias("count"))
    .filter(F.expr("count > 1")) # get rows that are duplicated, those are the pairs we want
    .withColumn("page_a", F.col("pair")[0]) # get page_a and page_b cols from pairs
    .withColumn("page_b", F.col("pair")[1])
    .drop("pair") 
    .select("page_a", "page_b")
    .repartition(5) # repartition into 5 parquet files instead of a bunch of small ones
    .write.mode("OVERWRITE").parquet(os.environ['PAGE_PAIRS_OUTPUT'])
)

